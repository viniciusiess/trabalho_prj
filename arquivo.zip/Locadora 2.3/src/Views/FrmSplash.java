package Locadora.Views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FrmSplash extends JDialog implements ActionListener
{
    private Timer timer;
    private long total,parcial; 
    private JProgressBar progressBar;
    public FrmSplash()
    {
        setSize(new Dimension(420,280));
        setLocationRelativeTo(null);
        setModal(true);
        setUndecorated(true);
        timer = new Timer(100 ,this);
        total = 0;
        parcial = 0;

        JLabel titulo = new JLabel("Cadastro DVD"); 
        add(titulo, BorderLayout.NORTH);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setVerticalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Orbitron", Font.BOLD, 16));
        titulo.setPreferredSize(new Dimension(0,36));

        JLabel img = new JLabel();
        ImageIcon iconLogo = new ImageIcon("resources/banner.png");
        img.setIcon(iconLogo);
        add(img, BorderLayout.CENTER);

        UIManager.put("ProgressBar.background", Color.LIGHT_GRAY);
        UIManager.put("ProgressBar.foreground", new Color(97, 64, 153));

        progressBar = new JProgressBar(0, 100);
        progressBar.setValue(0);
        progressBar.setStringPainted(true);
        progressBar.setPreferredSize(new Dimension(367,9));
        JPanel pnl = new JPanel();
        pnl.setPreferredSize(new Dimension(0,30));
        add(pnl, BorderLayout.SOUTH);
        pnl.add(progressBar);
    }
    public void actionPerformed(ActionEvent ae) {
        parcial += 100;
        if (parcial>total)
            parcial = total;
        double perc = 100.0*parcial/total;
        progressBar.setValue((int)perc);
        if (parcial>=total)
        {
            timer.stop();
            hide();
        }
    }

    private void start(long millis)
    {
        total = millis;
        parcial = 0;
        timer.start();
        show();
    }

    public static void executar(long millis)
    {
        FrmSplash frm = new FrmSplash();
        frm.start(millis);    
    }
    
    public static void main(String args[])
    {
        FrmSplash.executar(5000);
        System.out.println("tchau!");
        System.exit(0);
    }
}