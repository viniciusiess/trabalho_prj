package Locadora.Views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class FrmMenu extends JDialog implements ActionListener
{
    private int opc;
    private HashMap<JButton, Integer> dic = new HashMap<JButton, Integer>();
    public FrmMenu()
    {
        setTitle("Cadadastro de Filmes");
        setSize(new Dimension(400,600));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setModal(true);
        setLayout(new FlowLayout());

        int i = 1;
        for(String s : new String[]{"1 - inserir um filme","2 - remover dado o codigo","3 - alterar dado o codigo", "4 - pesquisar valor do aluguel dado o codigo","5 - listar todos","6 - listar dado parte titulo ou estilo","7 - importar txt", "8 - exportar txt", "9 - importar bin", "10 - exportar bin", "11 - sair"})
        {
             JButton btn = new JButton(s);
             btn.setPreferredSize(new Dimension(350,40));
             dic.put(btn, i);
             i++;
             add(btn);
             btn.addActionListener(this);
        }     
    }

    public void actionPerformed(ActionEvent e)
    {
       JButton btn = (JButton)e.getSource(); 
       opc = dic.get(btn);
       hide();
    }

	public int executar()
    {
        opc = 11;
        show();
        return opc;
    }
     
    public static void main(String g[])
    {
       FrmMenu frm = new FrmMenu();
       JOptionPane.showMessageDialog(null, "Usuario escolheu:"+frm.executar());
       System.exit(0);
    }
} 