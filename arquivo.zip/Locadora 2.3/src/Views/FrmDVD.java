package Locadora.Views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Locadora.Entities.*;

public class FrmDVD extends JDialog implements ActionListener
{
    private JButton btnOk;
    private JButton btnCancel;

    private JTextField tbxTitulo;
    private JTextField tbxAno;
    private JTextField tbxCodigo;
    private JTextField tbxDuracao;
    private JTextField tbxEstilo;    
   
    private boolean confirmou=false;

    private JTextField criarTextField(JPanel pnlPai, String rotulo, int largura)
    {
        Panel pnl = new Panel(new FlowLayout(FlowLayout.LEFT));
        pnl.setPreferredSize(new Dimension(450,30));
        JLabel lbl = new JLabel(rotulo);
        lbl.setPreferredSize(new Dimension(100,30));
        JTextField tbx = new JTextField(largura);
        pnl.add(lbl);
        pnl.add(tbx);
        pnlPai.add(pnl);        
        return tbx;
    }

    public FrmDVD()
    {
        setTitle("Editar Dados do DVD");
        setSize(new Dimension(500,270));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setModal(true);
        JPanel pnlBotoes,pnlDados;

        pnlBotoes = new JPanel();
        ((FlowLayout)pnlBotoes.getLayout()).setHgap(70);
        pnlDados = new JPanel();

        add(pnlBotoes, BorderLayout.SOUTH); 
        add(pnlDados, BorderLayout.CENTER);

        btnOk = new JButton("Ok");
        btnOk.setPreferredSize(new Dimension(100,25));
        btnOk.addActionListener(this);
        pnlBotoes.add(btnOk);

        btnCancel = new JButton("Cancelar");
        btnCancel.setPreferredSize(new Dimension(100,25));
        btnCancel.addActionListener(this);
        pnlBotoes.add(btnCancel);

        tbxCodigo = criarTextField(pnlDados,"Codigo", 10);
        tbxTitulo = criarTextField(pnlDados,"Titulo", 30);
        tbxAno = criarTextField(pnlDados,"Ano", 10);
        tbxDuracao = criarTextField(pnlDados,"Duracao", 10);
        tbxEstilo = criarTextField(pnlDados,"Estilo", 20);
    }

    public void actionPerformed(ActionEvent e){
        if (e.getSource()==btnOk)
            confirmou = true;
        hide();
    }

    private void atualizarTela(DVD d)
    {
        tbxCodigo.setText(""+d.getCodigo());
        tbxTitulo.setText(d.getTitulo());
        tbxAno.setText(""+d.getAno());
        tbxDuracao.setText(""+d.getDuracao());
        tbxEstilo.setText(d.getEstilo());
    } 

    private void atualizarObjeto(DVD d)
    {
        d.setCodigo(Integer.parseInt(tbxCodigo.getText()));
        d.setTitulo(tbxTitulo.getText());
        d.setAno(Integer.parseInt(tbxAno.getText()));
        d.setDuracao(Integer.parseInt(tbxDuracao.getText()));
        d.setEstilo(tbxEstilo.getText());
    } 

    public boolean executar(DVD d)
    {
        atualizarTela(d);
        confirmou = false;
        show();
        if (confirmou)
        {
            atualizarObjeto(d);
            return true;
        }
        else
            return false;
    }

    public static void main(String args[]){
        FrmDVD frm = new FrmDVD();
        DVD d = new DVD();
        d.setTitulo("Filme de Teste");
        d.setEstilo("Ruim");
        if (frm.executar(d))
            System.out.println("Confirmou!");
        else           
            System.out.println("Cancelou!");
        System.out.println(d.getTitulo());
        System.exit(0);
    }
}