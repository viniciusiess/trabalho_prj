package Locadora.Views;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import javax.swing.table.*;
import Locadora.Entities.*;
import Locadora.Services.*;

class DataModelDVD extends AbstractTableModel 
{
    private java.util.List<DVD> lstDVD = new ArrayList<DVD>();
    public DataModelDVD()
    {
    }
    public void update(Iterable<DVD> dvds)
    {
        for (DVD dvd : dvds)
           lstDVD.add(dvd);
        fireTableDataChanged();
    }
    public String getColumnName(int col)
    {
        switch (col){
            case 0: return "#";
            case 1: return "Codigo";
            case 2: return "Titulo";
            case 3: return "Estilo";
            case 4: return "Ano";
            case 5: return "Duração";
            case 6: return "Aluguel";
            default:return "desconhecido";
        }
    }
    public int getColumnCount() { return 7; }
    public int getRowCount()    { return lstDVD.size(); }
    public Object getValueAt(int row, int col) 
    {
        DVD d = lstDVD.get(row); 
        switch (col){
            case 0: return row;
            case 1: return d.getCodigo();
            case 2: return d.getTitulo();
            case 3: return d.getEstilo();
            case 4: return d.getAno();
            case 5: return d.getDuracao();
            case 6: return d.getAluguel();
            default:return "desconhecido";
        }
    }
}

 
public class CtrlListar extends JPanel
{
    private JTable tbl;
    private DataModelDVD mdl; 
    public CtrlListar()
    {
      mdl = new DataModelDVD();
      tbl = new JTable(mdl);
      tbl.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
      tbl.getColumnModel().getColumn(0).setPreferredWidth(10);
      JScrollPane scrollpane = new JScrollPane(tbl);
      this.setLayout(new BorderLayout());
      add(scrollpane, BorderLayout.CENTER);
    }

    public void update(Iterable<DVD> dvds)
    {
        mdl.update(dvds);
    }
    public static void main(String []args)
    {
        JFrame frm = new JFrame();
        frm.setSize(new Dimension(600,400));
        frm.setTitle("Teste de CtrlListar");
        frm.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frm.setLocationRelativeTo(null);
        CtrlListar ctr = new CtrlListar();
        frm.add(ctr);
        DVDService srvDVD = new DVDService();
        frm.show(); 
        ctr.update(srvDVD.listar());
    }
}