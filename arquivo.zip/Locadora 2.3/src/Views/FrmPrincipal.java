package Locadora.Views;

import Locadora.Entities.*;
import Locadora.Services.*;

import javax.swing.*;

public class FrmPrincipal
{
    private FrmMenu guiMenu = new FrmMenu();
    private FrmDVD guiDVD = new FrmDVD();
    private FrmListar guiListar = new FrmListar();
    private DVDService srvDVD = new DVDService();
 
    private void inserir()
    {
       DVD ficha = new DVD();
       guiDVD.executar(ficha);
       srvDVD.inserir(ficha);
    }
    private int lerCodigo(String msg)
    {
        String resp = JOptionPane.showInputDialog(msg);
        if (resp==null)
            return -1;
        else 
            return Integer.parseInt(resp);
    }
    private String lerTexto(String msg)
    {
        String resp = JOptionPane.showInputDialog(msg);
        if (resp==null)
            return "";
        else 
            return resp;
    }
    private void remover()
    {
         int cod = lerCodigo("Entre com o codigo do filme a ser removido");
         if (!srvDVD.existe(cod))
            JOptionPane.showMessageDialog(null,"filme nao encontrado!", "Aviso", JOptionPane.INFORMATION_MESSAGE);
         else
         {
             srvDVD.remover(cod);    
             JOptionPane.showMessageDialog(null,"filme removido com sucesso!");
         }
    }
    private void alterar()
    {
        int cod = lerCodigo("Entre com o codigo do filme a ser alterado");
        DVD ficha = srvDVD.obterPeloCodigo(cod);
        if (ficha==null)
            JOptionPane.showMessageDialog(null,"filme nao encontrado!", "Aviso", JOptionPane.INFORMATION_MESSAGE);
         else
         {
             guiDVD.executar(ficha);
             srvDVD.alterar(cod,ficha);    
             JOptionPane.showMessageDialog(null,"filme atualizado com sucesso!");
         }
    }
    private void consultarAluguel()
    {
         int cod = lerCodigo("Entre com o codigo do filme a ser consultado o valor do aluguel");
         if (!srvDVD.existe(cod))
             JOptionPane.showMessageDialog(null,"filme nao encontrado!", "Aviso", JOptionPane.INFORMATION_MESSAGE);
          else          
             JOptionPane.showMessageDialog(null,String.format("aluguel = R$%10.2f\n",srvDVD.aluguel(cod)));
    }

    private void listar()
    {
       guiListar.executar(srvDVD.listar());
    }

    private void filtrar()
    {
       String parte = lerTexto("Entre com parte do nome"); 
       guiListar.executar(srvDVD.listar(parte));
    }

    private void importartxt()
    { 
    }
    private void exportartxt()
    {
    }
    private void importarbin()
    {
    }
    private void exportarbin()
    {
    }

    public void executar()
    {
	  boolean acabou = false;             
        while (!acabou)
        {
            try{
              switch(guiMenu.executar())
              {
                case 1: inserir();			break;
                case 2: remover();			break;
                case 3: alterar();			break;
                case 4: consultarAluguel();	break;
                case 5: listar();			break;
                case 6: filtrar();			break;
                case 7: importartxt();		break;
                case 8: exportartxt();		break;
                case 9: importarbin();		break;
                case 10: exportarbin();		break;
                case 11: acabou = true;		break;
              }
       		} catch (BussinesException err)
       		{
          		JOptionPane.showMessageDialog(null,err.getMessage(),"Erro", JOptionPane.WARNING_MESSAGE);
       		} catch(Exception err)
       		{
          		JOptionPane.showMessageDialog(null,"Erro não esperado! entre em contato com os desenvolvedores\n\n"+err.getMessage(), "Erro Crítico", JOptionPane.ERROR_MESSAGE);
       		}
        }
    }
}