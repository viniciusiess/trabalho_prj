package Locadora.Repositories;


import java.io.*;
import Locadora.Entities.*;
import java.util.*;

public class ArqTXT
{
    private String _nomeArq;
    public ArqTXT(String nomeArq)
    {
       _nomeArq = nomeArq;
    } 

    public void gravar(Iterable<DVD> colecao)
    {
       try{
          FileOutputStream fs = new FileOutputStream(_nomeArq);
          OutputStreamWriter sr = new OutputStreamWriter(fs);
          BufferedWriter bw = new BufferedWriter(sr);  
          for(DVD d : colecao)
          {
             bw.write(d.getCodigo()+",");
             bw.write(d.getTitulo()+",");
             bw.write(d.getEstilo()+",");
             bw.write(d.getAno()+",");
             bw.write(d.getDuracao()+"");
             bw.newLine();
          }
          bw.close();
          sr.close();
          fs.close();
       }catch(Exception e)
       {
          e.printStackTrace();
          System.exit(0);
       }
    }
    public Iterable<DVD> ler()
    {
      try{
         File f = new File(_nomeArq);
	   List<DVD> lista = new LinkedList<DVD>();
         if (f.exists())
         {
            FileInputStream fs = new FileInputStream(f);
            InputStreamReader sr = new InputStreamReader(fs);
            BufferedReader br = new BufferedReader(sr);  
            String linha;
            //_locadora.limpar();
            while ( (linha = br.readLine())!=null ){
               if (linha.trim().length()>0)
               {
                  String []campos = linha.split(",");
                  DVD d = new DVD();
                  d.setCodigo(Integer.parseInt(campos[0]));
                  d.setTitulo(campos[1]);
                  d.setEstilo(campos[2]);
                  d.setAno(Integer.parseInt(campos[3]));
                  d.setDuracao(Integer.parseInt(campos[4]));
                  lista.add(d);
               }      
            }
            br.close();
            sr.close();
            fs.close();
         }
         return lista;
       }catch(Exception e)
       {
          e.printStackTrace();
          System.exit(0);
          return null;
       }
    }
}