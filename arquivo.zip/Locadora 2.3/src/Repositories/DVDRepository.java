package Locadora.Repositories;

import java.sql.*;
import java.util.*;
import java.io.*;
import Locadora.Entities.*;

/*
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
*/


public class DVDRepository
{
    private static final String _NOME_BANCO_ = "dados.db";
    private Connection _con;
    public DVDRepository()
    {
       try {
           Class.forName("org.sqlite.JDBC");
           File f = new File(_NOME_BANCO_);
           if (!f.exists())
              criarBanco();
      }catch(Exception e)  
      {
         e.printStackTrace(); 
         System.exit(0);
      }
    }
    private void criarBanco()
    {
      try{
           conectar();
  	   Statement statement = _con.createStatement();
           statement.executeUpdate("create table dvd (codigo int not null, titulo VARCHAR(50), ano int, duracao int, estilo varchar(20), CONSTRAINT codigo_unico PRIMARY KEY (codigo))");
           desconectar();
      }catch(Exception e)
      { 
         e.printStackTrace(); 
         System.exit(0);
      }
    }
    private Connection conectar()
    {
       try{ 
          if (_con==null)
             _con = DriverManager.getConnection("jdbc:sqlite:"+_NOME_BANCO_);
          return _con;
      }catch(Exception e)
      { 
         e.printStackTrace(); 
         System.exit(0);
         return null;
      }
    }

    private void desconectar()
    {
       try{
          _con.close();
          _con = null;
      }catch(Exception e)
      { 
         e.printStackTrace(); 
         System.exit(0);
      }
    }

    public void inserir(DVD d)
    {
        try{
            conectar();
    	    PreparedStatement statement = _con.prepareStatement("insert into dvd(codigo,titulo,ano,duracao,estilo) values (?,?,?,?,?)");
            statement.setInt(1, d.getCodigo());
            statement.setString(2, d.getTitulo());
            statement.setInt(3, d.getAno());
            statement.setInt(4, d.getDuracao());
            statement.setString(5, d.getEstilo());
	    statement.executeUpdate();     
            desconectar();
        }catch(Exception e){
		e.printStackTrace();
		System.exit(0);
	}
    }

    public void remover(int codigo)
    {
        try{
            conectar();
    	    PreparedStatement statement = _con.prepareStatement("delete from dvd where codigo=?");
            statement.setInt(1, codigo);
	    statement.executeUpdate();        
            desconectar();
        }catch(Exception e){
		e.printStackTrace();
		System.exit(0);
	}
    }

    public void alterar(int cod, DVD d)
    {
        try{
            conectar();
    	    PreparedStatement statement = _con.prepareStatement("update dvd set codigo=?,titulo=?,ano=?,duracao=?,estilo=? where codigo=?");
            statement.setInt(1, d.getCodigo());
            statement.setString(2, d.getTitulo());
            statement.setInt(3, d.getAno());
            statement.setInt(4, d.getDuracao());
            statement.setString(5, d.getEstilo());
            statement.setInt(6, cod);
	    statement.executeUpdate();        
            desconectar();
        }catch(Exception e){
		e.printStackTrace();
		System.exit(0);
	}
    }

    public DVD get(int cod)
    {
        try{
            conectar();
    	    PreparedStatement statement = _con.prepareStatement("select codigo, titulo, ano, duracao, estilo from dvd where codigo=?");
            statement.setInt(1, cod);
	    ResultSet rs = statement.executeQuery();        
            DVD d = null;
            if (rs.next())
            {
                d = new DVD();  
                d.setCodigo(rs.getInt(1));
                d.setTitulo(rs.getString(2));
                d.setAno(rs.getInt(3));
                d.setDuracao(rs.getInt(4));
                d.setEstilo(rs.getString(5));
            }
            desconectar();
            return d;
        }catch(Exception e){
		e.printStackTrace();
		System.exit(0);
		return null;
	}
    }

    public Iterable<DVD> listar()
    {
        try{
            conectar();
    	    PreparedStatement statement = _con.prepareStatement("select codigo, titulo, ano, duracao, estilo from dvd order by codigo");
	    ResultSet rs = statement.executeQuery();        
            List<DVD> list = new LinkedList<DVD>();
            while (rs.next())
            {
                DVD d = new DVD();  
                d.setCodigo(rs.getInt(1));
                d.setTitulo(rs.getString(2));
                d.setAno(rs.getInt(3));
                d.setDuracao(rs.getInt(4));
                d.setEstilo(rs.getString(5));
                list.add(d);
            }
            desconectar();
            return list;
        }catch(Exception e){
		e.printStackTrace();
		System.exit(0);
                return null;
	}
    }    
}
