package Locadora.Repositories;


import java.io.*;
import Locadora.Entities.*;
import java.util.*;


public class ArqBin
{
    private String _nomeArq;
    public ArqBin(String nomeArq)
    {
       _nomeArq = nomeArq;
    } 

    public void gravar(Iterable<DVD> colecao)
    {
       try{
          FileOutputStream fs = new FileOutputStream(_nomeArq);
          DataOutputStream ds = new DataOutputStream(fs);
          for(DVD d : colecao)
          {
             ds.writeInt(d.getCodigo());
             ds.writeUTF(d.getTitulo());
             ds.writeUTF(d.getEstilo());
             ds.writeInt(d.getAno());
             ds.writeInt(d.getDuracao());
          }
          ds.close();
          fs.close();
       }catch(Exception e)
       {
          e.printStackTrace();
          System.exit(0);
       }
    }
    public Iterable<DVD> ler()
    {
      try{
         File f = new File(_nomeArq);
         List<DVD> lista = new LinkedList<DVD>();
         if (f.exists())
         {
            FileInputStream fs = new FileInputStream(f);
            DataInputStream ds = new DataInputStream(fs);
            while ( ds.available()>0 ){
                DVD d = new DVD();
                d.setCodigo(ds.readInt());
                d.setTitulo(ds.readUTF());
                d.setEstilo(ds.readUTF());
                d.setAno(ds.readInt());
                d.setDuracao(ds.readInt());
                lista.add(d);
            }
            ds.close();
            fs.close();
         }
         return lista;
       }catch(Exception e)
       {
          e.printStackTrace();
          System.exit(0);
          return null;
       }
    }
}