package Locadora.Repositories;


import java.io.*;
import Locadora.Entities.*;
import java.util.*;

public class ArqObj
{
    private String _nomeArq;
    public ArqObj(String nomeArq)
    {
       _nomeArq = nomeArq;
    } 

    public void gravar(Iterable<DVD> colecao)
    {
       try{
          FileOutputStream fs = new FileOutputStream(_nomeArq);
          ObjectOutputStream ds = new ObjectOutputStream(fs);
          for(DVD d : colecao)
             ds.writeObject(d);
          ds.close();
          fs.close();
       }catch(Exception e)
       {
          e.printStackTrace();
          System.exit(0);
       }
    }
    public Iterable<DVD> ler()
    {
      try{
         File f = new File(_nomeArq);
         List<DVD> lista = new LinkedList<DVD>();
         if (f.exists())
         {
            FileInputStream fs = new FileInputStream(f);
            ObjectInputStream ds = new ObjectInputStream(fs);
            while ( fs.available()>0 ){
                DVD d = (DVD)ds.readObject();
                lista.add(d);
            }
            ds.close();
            fs.close();           
         }
         return lista;
       }catch(Exception e)
       {
          e.printStackTrace();
          System.exit(0);
          return null;
       }
    }
}