package Locadora.Services;

public class BussinesException extends Error
{
    public BussinesException(String msg)
    {
        super(msg);
    }
}
