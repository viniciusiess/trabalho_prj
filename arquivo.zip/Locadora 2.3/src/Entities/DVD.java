package Locadora.Entities;

import java.io.Serializable;

public class DVD implements Serializable{
    private String titulo;
    private int ano,codigo,duracao;
    private String estilo;

    public String getTitulo()           { return titulo; }
    public int    getCodigo()           { return codigo; }
    public String getEstilo()           { return estilo; }
    public int    getAno()              { return ano;    }
    public int    getDuracao()          { return duracao;}
    public double getAluguel()          { return ano<2020?3.0:5.0; }

    public void setTitulo(String v)     { titulo = v; }
    public void setCodigo(int v)        { codigo = v; }
    public void setEstilo(String v)     { estilo = v; }
    public void setAno(int v)           { ano = v;    }
    public void setDuracao(int v)       { duracao = v;}
}
