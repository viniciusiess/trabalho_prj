package Locadora;

import Locadora.Views.*;

public class Principal {
    public static void main (String[] args) {
        FrmSplash.executar(5000);
        FrmPrincipal p = new FrmPrincipal();
        p.executar();
        System.exit(0);
   }
}